// src/pages/ProfileDetailPage.js
import React from 'react';
import { useParams } from 'react-router-dom'; // URLパラメータ取得用
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import Link from '@mui/material/Link'; // MUI Link
import YouTubeIcon from '@mui/icons-material/YouTube';
import TwitterIcon from '@mui/icons-material/Twitter';
import InstagramIcon from '@mui/icons-material/Instagram';
import ArrowBackIcon from '@mui/icons-material/ArrowBack'; // 戻るボタン用アイコン
import { Link as RouterLink } from 'react-router-dom'; // React RouterのLink

import { profiles } from '../data/profiles'; // プロフィールデータをインポート

function ProfileDetailPage() {
  const { id } = useParams(); // URLからidパラメータを取得
  const profile = profiles.find(p => p.id === id); // 該当するプロフィールを検索

  if (!profile) {
    return (
      <Container maxWidth="md" sx={{ mt: 4 }}>
        <Typography variant="h5" color="error">
          指定されたプロフィールは見つかりませんでした。
        </Typography>
        <Button
          variant="outlined"
          startIcon={<ArrowBackIcon />}
          component={RouterLink}
          to="/relation-chart"
          sx={{ mt: 3 }}
        >
          相関図へ戻る
        </Button>
      </Container>
    );
  }

  return (
    <Container maxWidth="md" sx={{ mt: 4 }}>
      <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', mb: 4 }}>
        <Avatar alt={profile.name} src={profile.avatar} sx={{ width: 150, height: 150, mb: 2 }} />
        <Typography variant="h4" component="h1" gutterBottom align="center">
          {profile.name}
        </Typography>
        <Typography variant="body1" color="text.secondary" align="center" sx={{ mb: 3 }}>
          {profile.shortBio}
        </Typography>
        <Box sx={{ display: 'flex', gap: 2, mb: 3 }}>
          {profile.sns.youtube && (
            <Link href={profile.sns.youtube} target="_blank" rel="noopener">
              <YouTubeIcon color="error" fontSize="large" />
            </Link>
          )}
          {profile.sns.x && (
            <Link href={profile.sns.x} target="_blank" rel="noopener">
              <TwitterIcon color="primary" fontSize="large" />
            </Link>
          )}
          {profile.sns.instagram && (
            <Link href={profile.sns.instagram} target="_blank" rel="noopener">
              <InstagramIcon sx={{ color: '#E4405F' }} fontSize="large" />
            </Link>
          )}
        </Box>
      </Box>

      <Typography variant="body1" sx={{ whiteSpace: 'pre-line' }}> {/* pre-lineで改行を反映 */}
        {profile.longBio}
      </Typography>

      <Button
        variant="outlined"
        startIcon={<ArrowBackIcon />}
        component={RouterLink}
        to="/relation-chart"
        sx={{ mt: 4 }}
      >
        相関図へ戻る
      </Button>
    </Container>
  );
}

export default ProfileDetailPage;